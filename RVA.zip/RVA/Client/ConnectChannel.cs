﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public class ConnectChannel
    {
        public ISocialNetwork proxy;

        private static ConnectChannel instance;

        public static ConnectChannel Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ConnectChannel();
                }
                return instance;
            }
        }

        public ConnectChannel()
        {
            NetTcpBinding binding = new NetTcpBinding();
            binding.TransactionFlow = true;
            ChannelFactory<ISocialNetwork> factory = new ChannelFactory<ISocialNetwork>
                 (binding, new EndpointAddress(String.Format("net.tcp://localhost:4000/ISocialNetwork")));

            proxy = factory.CreateChannel();
        }
    }
}
