﻿using Client.Commands;
using Client.View;
using Common;
using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Client.ViewModel
{
    public class HomeViewModel : INotifyPropertyChanged
    {
        private BindingList<User> bindingUsers;
        private BindingList<User> bindingFriend;
       // private BindingList<User> bindingRequests;
        private static string usernameOfLogged;
        public User ChoosedList { get; set; }
        public User ChoosedListF { get; set; }

        public ComboBox comboHomeViewModel;
        public string FriendType { get; set; }
        public HomeViewModel()
        {
            AddUserCommand = new AddUserCommand(this);
            LogOutCommand = new LogOutCommand(this);
            ChangeWindowUserCommand = new ChangeWindowUserCommand(this);
            BindingUser = ConnectChannel.Instance.proxy.GetAllUsers();
            DeleteListCommand = new DeleteListCommand(this);
            RefreshListCommand = new RefreshListCommand(this);
            AddMyFriendCommand = new AddMyFriendCommand(this);
            BindingFriend = ConnectChannel.Instance.proxy.GetAllFriends(MainViewModel.UsernameHelper);
            FriendRequestsCommand = new FriendRequestsCommand(this);
            SearchUserCommand = new SearchUserCommand(this);
            DuplicateUserCommand = new DuplicateUserCommand(this);
            UndoCommand = new UndoCommand(this);
            RedoCommand = new RedoCommand(this);
            AddTypeViewCommand = new AddTypeViewCommand(this);
        }

        private ILogger logger = new Logger();

        public ILogger Logger { get => logger; set => logger = value; }

        public ICommand AddTypeViewCommand
        {
            get;
            private set;
        }

        public ICommand SearchUserCommand
        {
            get;
            private set;
        }

        public ICommand DuplicateUserCommand
        {
            get;
            private set;
        }

        public ICommand FriendRequestsCommand
        {
            get;
            private set;
        }

        public ICommand RefreshListCommand
        {
            get;
            private set;
        }

       
        public ICommand AddMyFriendCommand
        {
            get;
            private set;
        }

        public BindingList<User> BindingUser
        {
            get
            {
                return bindingUsers;
            }
            set
            {
                bindingUsers = value;
                OnPropertyChanged("BindingUser");
            }
        }

     
        public BindingList<User> BindingFriend
        {
            get
            {
                return bindingFriend;
            }
            set
            {
                bindingFriend = value;
                OnPropertyChanged("BindingFriend");
            }
        }

        public ICommand DeleteListCommand
        {
            get;
            private set;
        }

        public ICommand AddUserCommand
        {
            get;
            private set;
        }

        public ICommand LogOutCommand
        {
            get;
            private set;
        }

        public bool CanAdd
        {
            get
            {
                return true;
            }
        }
        public bool CanAddUser
        {
            get
            {
                if (TempUser.RoleOfUser.Equals("Admin"))
                {
                    return true;
                }
                return false;

            }
        }

        public bool CanDuplicateUser
        {
            get
            {
                if (ChoosedList == null)
                {
                    return false;
                }
                return true;
            }
        }

        public bool CanAddType
        {
            get
            {
                if (ChoosedListF == null)
                {
                    return false;
                }
                return true;
            }
        }

        public void AddType()
        {
            try
            {
                ConnectChannel.Instance.proxy.AddTypeF("best");
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public void DuplicateCurrentUser()
        {
            try
            {
                UndoRedoDataBase.Undo.Add(new UndoRedo(ChoosedList, "ADD"));
                Logger.LogKlijent("\nUser successfully duplicated: " + ChoosedList.Name, DateTime.Now);
                ConnectChannel.Instance.proxy.DuplicateUser(ChoosedList);

            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        public void AddUser()
        {
            try
            {
                Window w = new AddUserWindow();
                w.DataContext = new AddUserViewModel() { Window = w };
                w.Show();
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect to server.");
            }
        }

      

        public bool CanLogOut
        {
            get
            {
                return true;
            }
        }


        public void LogOut()
        {
            new MainWindow().Show();
            Window.Close();

        }

        public bool CanChangeUser
        {
            get
            {
                return true;

            }
        }

        public void ChangeUser()
        {
            try
            {
                Window w = new ChangeUserWindow();
                w.DataContext = new ChangeUserViewModel() { Window = w, ChangeUser = this.TempUser };
                w.ShowDialog();

            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }

        public void AddView()
        {
            try
            {
                Window w = new AddTypeofFriendWindow(ChoosedListF.Username);
                w.DataContext = new AddTypeOfFriendViewModel() { Window = w, FriendName = ChoosedListF.Username };
                w.Show();
            }
            catch (Exception e)
            {
                // Console.WriteLine("ADDType exc" + e.Message);
                MessageBox.Show(Window, "Can't connect to server." + e.Message);
            }
        }
        public bool CanDeleteList
        {
            get
            {
                if (ChoosedList == null)
                {
                    return false;
                }
                return true;
            }
        }

        public bool CanAddMyUser
        {
            get
            {
                if (ChoosedList == null)
                {
                    return false;
                }
                return true;
            }
        }

        public bool CanAddMyFriend
        {
            get
            {
                if (ChoosedList == null)
                {
                    return false;
                }
                return true;
            }
        }

        public void AddCurrentFriend()
        {
            try
            {
                UndoRedoDataBase.Undo.Add(new UndoRedo(ChoosedList, "ADD"));
                ConnectChannel.Instance.proxy.AddMyFriend(MainViewModel.UsernameHelper, ChoosedList.Username);
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }

        public void DeleteCurentList()
        {
            try
            {
                UndoRedoDataBase.Undo.Add(new UndoRedo(ChoosedList, "DELETE"));
                ConnectChannel.Instance.proxy.DeleteList(ChoosedList);
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }

        public bool CanShowFriendRequests
        {
            get
            {
                return true;

            }
        }

        public void ShowCurrentFriendRequests()
        {
           
            try
            {
                Window w = new FriendRequestsWindow();
                w.DataContext = new FriendRequestsViewModel() { Window = w, };
                w.ShowDialog();
            }
            catch (Exception)
            {
                MessageBox.Show(Window, "Can't connect to server.");
            }


        }
        public User TempUser { get; set; }

        public Window Window { get; set; }

        public ICommand ChangeWindowUserCommand
        {
            get;
            private set;
        }
        public static string UsernameOfLogged { get => usernameOfLogged; set => usernameOfLogged = value; }

        public void RefreshLists()
        {
            try
            {

                BindingUser = ConnectChannel.Instance.proxy.GetAllUsers();
                BindingFriend = ConnectChannel.Instance.proxy.GetAllFriends(MainViewModel.UsernameHelper);
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }

        public bool CanDoUndo
        {
            get
            {
                if (UndoRedoDataBase.Undo.Count != 0)
                    return true;
                return false;
            }
        }

        public ICommand UndoCommand
        {
            get;
            private set;
        }

        public void Undo()
        {
            UndoRedoDataBase.Redo.Add(UndoRedoDataBase.Undo[UndoRedoDataBase.Undo.Count - 1]);

            if (UndoRedoDataBase.Undo[UndoRedoDataBase.Undo.Count - 1].Operation == "ADD")
            {
                ConnectChannel.Instance.proxy.DeleteList(UndoRedoDataBase.Undo[UndoRedoDataBase.Undo.Count - 1].Useri);
                BindingUser = ConnectChannel.Instance.proxy.GetAllUsers();
            }
            else if (UndoRedoDataBase.Undo[UndoRedoDataBase.Undo.Count - 1].Operation == "DELETE")
            {
                ConnectChannel.Instance.proxy.AddUser(UndoRedoDataBase.Undo[UndoRedoDataBase.Undo.Count - 1].Useri);
                BindingUser = ConnectChannel.Instance.proxy.GetAllUsers();
            }
            //else if (UndoRedoDataBase.Undo[UndoRedoDataBase.Undo.Count - 1].Operation == "EDIT")
            //{
            //    ConnectChannel.Instance.proxy.Promeni(UndoRedoDataBase.Undo[UndoRedoDataBase.Undo.Count - 1].Skolai);
            //    BindingSchool = ConnectChannel.Instance.proxy.GetAllSchools();
            //}

            UndoRedoDataBase.Undo.RemoveAt(UndoRedoDataBase.Undo.Count - 1);
        }

        public bool CanDoRedo
        {
            get
            {
                if (UndoRedoDataBase.Redo.Count != 0)
                    return true;
                return false;
            }
        }

        public ICommand RedoCommand
        {
            get;
            private set;
        }

        public bool CanSearchUser
        {
            get
            {
                if (SearchText == null)
                {
                    return false;
                }
                return true;
            }
        }

        public string SearchText { get; set; }

        public void SearchUser()
        {
            try
            {
                BindingList<User> TempList = new BindingList<User>();

                foreach (var u in BindingUser)
                {
                    string s = u.Name;
                    s.Replace(" ", string.Empty);
                    if (s.Contains(SearchText))
                    {
                        TempList.Add(u);
                    }
                }
                BindingUser = TempList;
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }

        public void Redo()
        {
            UndoRedoDataBase.Undo.Add(UndoRedoDataBase.Redo[UndoRedoDataBase.Redo.Count - 1]);

            if (UndoRedoDataBase.Redo[UndoRedoDataBase.Redo.Count - 1].Operation == "DELETE")
            {
                ConnectChannel.Instance.proxy.DeleteList(UndoRedoDataBase.Redo[UndoRedoDataBase.Redo.Count - 1].Useri);
                BindingUser = ConnectChannel.Instance.proxy.GetAllUsers();
            }
            else if (UndoRedoDataBase.Redo[UndoRedoDataBase.Redo.Count - 1].Operation == "ADD")
            {
                ConnectChannel.Instance.proxy.AddUser(UndoRedoDataBase.Redo[UndoRedoDataBase.Redo.Count - 1].Useri);
                BindingUser = ConnectChannel.Instance.proxy.GetAllUsers();
            }
            //else if (UndoRedoDataBase.Redo[UndoRedoDataBase.Redo.Count - 1].Operation == "ADDFRIEND")
            //{
            //    ConnectChannel.Instance.proxy.AddMyFriend(UndoRedoDataBase.Redo[UndoRedoDataBase.Redo.Count - 1].Useri.Username);
            //    BindingFriend = ConnectChannel.Instance.proxy.GetAllFriends(MainViewModel.UsernameHelper);
            //}


            UndoRedoDataBase.Redo.RemoveAt(UndoRedoDataBase.Redo.Count - 1);
        }
    }
}
