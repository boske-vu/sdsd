﻿using Client.Commands;
using Common;
using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Client.ViewModel
{
    class ChangeUserViewModel : INotifyPropertyChanged
    {
        public ChangeUserViewModel()
        {
            ChangeUserCommand = new ChangeUserCommand(this);
            ChangeUser = new User();
        }
        private ILogger logger = new Logger();

        public ILogger Logger { get => logger; set => logger = value; }
        public Window Window { get; set; }
        public User ChangeUser { get; set; }


        public ICommand ChangeUserCommand
        {
            get;
            private set;
        }


        public bool CanChangeUser
        {
            get
            {
                return !String.IsNullOrWhiteSpace(ChangeUser.Name) &&
                        !String.IsNullOrWhiteSpace(ChangeUser.LastName);
            }
        }


        public void ChangeCurrentUser()
        {
            try
            {
                Logger.LogKlijent("\nUspesno ste promenili korisnika sa imenom: " + ChangeUser.Name, DateTime.Now);
                ConnectChannel.Instance.proxy.ChangeUser(ChangeUser);
                Window.Close();
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
