﻿using Client.Commands;
using Client.View;
using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Client.ViewModel
{
    class MainViewModel : INotifyPropertyChanged
    {
        public MainViewModel()
        {

            LogInCommand = new LogInCommand(this);
        }


        public static string UsernameHelper { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public Window Window { get; set; }

        public ICommand LogInCommand
        {
            get;
            private set;
        }

        public bool CanLogIn
        {
            get
            {
                return !String.IsNullOrEmpty(UserName) && !String.IsNullOrEmpty(Password);


            }
        }

        public void LogIn()
        {
            User user = ConnectChannel.Instance.proxy.findUserByUsername(UserName);

            
            if (user == null)
            {
                MessageBox.Show("You have not registered");
            }
            else
            {
                UsernameHelper = user.Username;
                if (user.Password == Password)
                {
                    MessageBox.Show("Welcome " + user.Name + " " + user.LastName + "!", "SocialNetwork", MessageBoxButton.OK, MessageBoxImage.Information);
                    
                    new Home(user).Show();
                    Window.Close();
                }
                else
                {
                    MessageBox.Show("Wrong password");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
