﻿using Client.Commands;
using Client.View;
using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Client.ViewModel
{
    public class FriendRequestsViewModel : INotifyPropertyChanged
    {
        private BindingList<User> bindingRequests;

        public FriendRequestsViewModel()
        {
            //FriendRequestsCommand = new FriendRequestsCommand(this);
            AcceptFriendCommand = new AcceptFriendCommand(this);
            BindingRequests = ConnectChannel.Instance.proxy.GetAllRequests(MainViewModel.UsernameHelper);
        }

        public User ChoosedList2 { get; set; }

        public Window Window { get; set; }

        public bool CanAcceptFriend
        {
            get
            {
                if (ChoosedList2 == null)
                {
                    return false;
                }
                return true;
            }
        }


        public void AcceptFriend()
        {
            try
            {
                //UndoRedoDataBase.Undo.Add(new UndoRedo(ChoosedList, "DELETE"));
                ConnectChannel.Instance.proxy.AcceptFriend(MainViewModel.UsernameHelper, ChoosedList2.Username);
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }

        public BindingList<User> BindingRequests
        {
            get
            {
                return bindingRequests;
            }
            set
            {
                bindingRequests = value;
                OnPropertyChanged("BindingRequests");
            }
        }

        public ICommand FriendRequestsCommand
        {
            get;
            private set;
        }

        public ICommand AcceptFriendCommand
        {
            get;
            private set;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
