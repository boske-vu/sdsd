﻿using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.ViewModel
{
    class ShowUsersViewModel : INotifyPropertyChanged
    {
        public ShowUsersViewModel(User u)
        {
        }

        public User ShowPlayList { get; set; }
        private List<User> bindingUser;

        public List<User> BindingUser
        {
            get
            {
                return bindingUser;
            }
            set
            {
                bindingUser = value;
                OnPropertyChanged("BindingUser");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

    }
}
