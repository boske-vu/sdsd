﻿using Client.Commands;
using Common;
using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Client.ViewModel
{
    class AddTypeOfFriendViewModel : INotifyPropertyChanged
    {
        public AddTypeOfFriendViewModel()
        {
            AddTypeOfFriendCommand = new AddTypeOfFriendCommand(this);
            
        }
        private ILogger logger = new Logger();

        public string ComboBox1 { get; set; }
        public ICommand AddTypeOfFriendCommand
        {
            get;
            private set;
        }

        //public string comboBoxModel { get; set; }
        public string FriendName { get; set; }
        public ILogger Logger { get => logger; set => logger = value; }
        public Window Window { get; set; }
        public User NewUser { get; set; }

        private bool[] checkBoxs = new bool[2] { false, false };

        public bool CanAddType2
        {
            get
            {
                return true;
            }
        }

        public void AddType2()
        {
            try
            {

                //UndoRedoDataBase.Undo.Add(new UndoRedo(ChoosedList, "ADD"));
                //Logger.LogKlijent("\nUser successfully duplicated: " + ChoosedList.Name, DateTime.Now);
                
                ConnectChannel.Instance.proxy.AddTypeOfFriend(MainViewModel.UsernameHelper, FriendName, ComboBox1.Substring(37));

            }
            catch(Exception e)
            {
                //Console.WriteLine("AddType exc" + e.Message);
                MessageBox.Show(Window, "Can't connect on server in AddTypeOfFriendViewModel" + e.Message);
            }
        }
        public bool[] CheckBoxes
        {
            get
            {
                return checkBoxs;
            }

            set
            {
                checkBoxs = value;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
