﻿using Client.Commands;
using Common;
using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Client.ViewModel
{
    public class AddUserViewModel : INotifyPropertyChanged
    {
        public AddUserViewModel()
        {
            AddNewUserCommand = new AddNewUserCommand(this);
            NewUser = new User();
        }
        private ILogger logger = new Logger();

        public ILogger Logger { get => logger; set => logger = value; }
        public Window Window { get; set; }
        public User NewUser { get; set; }

        private bool[] checkBoxs = new bool[2] { false, false };
        public bool[] CheckBoxes
        {
            get
            {
                return checkBoxs;
            }

            set
            {
                checkBoxs = value;
            }
        }

        public ICommand AddNewUserCommand
        {
            get;
            private set;
        }


        public bool CanAddNewUser
        {
            get
            {
                return !String.IsNullOrWhiteSpace(NewUser.Name) &&
                        !String.IsNullOrWhiteSpace(NewUser.LastName) &&
                        !String.IsNullOrWhiteSpace(NewUser.Username) &&
                        !String.IsNullOrWhiteSpace(NewUser.Password)
                         && (CheckBoxes[0] || CheckBoxes[1]);

            }
        }

        public void AddNewUser()
        {
            try
            {
                string[] roles = new string[2] { "Admin", "Korisnik" };
                if (CheckBoxes[0])
                    NewUser.RoleOfUser += roles[0];
                else
                {
                    NewUser.RoleOfUser += roles[1];
                }
                Logger.LogKlijent("\nSuccessfully added user: " + NewUser.Name, DateTime.Now);
                ConnectChannel.Instance.proxy.AddUser(NewUser);
                Window.Close();
            }
            catch
            {
                MessageBox.Show(Window, "Can't connect on server.");
            }
        }



        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
