﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Client.Channel
{
    public class ClientChannel
    {
        public ISocialNetwork proxy;
        private static ClientChannel instance;

        public static ClientChannel Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ClientChannel();
                }
                return instance;
            }
        }

        public ClientChannel()
        {
            NetTcpBinding binding = new NetTcpBinding();
            binding.TransactionFlow = true;
            ChannelFactory<ISocialNetwork> factory = new ChannelFactory<ISocialNetwork>(binding, new EndpointAddress(String.Format("net.tcp://localhost:4000/ISocialNetwork")));

            proxy = factory.CreateChannel();
        }

    }
}
