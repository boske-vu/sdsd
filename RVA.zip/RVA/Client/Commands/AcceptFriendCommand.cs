﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class AcceptFriendCommand : ICommand
    {
        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        private FriendRequestsViewModel hwvm;

        public AcceptFriendCommand(FriendRequestsViewModel hwvm)
        {
            this.hwvm = hwvm;
        }


        public bool CanExecute(object parameter)
        {
            return this.hwvm.CanAcceptFriend;
        }

        public void Execute(object parameter)
        {
            this.hwvm.AcceptFriend();
        }
    }
}

