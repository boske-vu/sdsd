﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class ChangeWindowUserCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private HomeViewModel hwmv;

        public ChangeWindowUserCommand(HomeViewModel hwmv)
        {
            this.hwmv = hwmv;
        }

        public bool CanExecute(object parameter)
        {
            return hwmv.CanChangeUser;
        }

        public void Execute(object parameter)
        {
            hwmv.ChangeUser();
        }
    }
}
