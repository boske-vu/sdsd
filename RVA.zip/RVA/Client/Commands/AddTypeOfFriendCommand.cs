﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class AddTypeOfFriendCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private AddTypeOfFriendViewModel hwmv;

        public string ComboBoxValue { get; set; }
        public AddTypeOfFriendCommand(AddTypeOfFriendViewModel hwmv)
        {
            this.hwmv = hwmv;
            //ComboBoxValue = 
        }

        public bool CanExecute(object parameter)
        {
            return hwmv.CanAddType2;
        }

        public void Execute(object parameter)
        {
            hwmv.AddType2();
        }
    }
}
