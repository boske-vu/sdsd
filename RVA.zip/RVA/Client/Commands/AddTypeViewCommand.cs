﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class AddTypeViewCommand : ICommand
    {
       
        private HomeViewModel hwmv;

        public AddTypeViewCommand(HomeViewModel hwmv)
        {
            this.hwmv = hwmv;
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return this.hwmv.CanAddType;
        }

        public void Execute(object parameter)
        {
            this.hwmv.AddView();
        }
    }
}
