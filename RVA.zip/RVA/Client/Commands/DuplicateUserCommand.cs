﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class DuplicateUserCommand : ICommand
    {
        private HomeViewModel hwvm;

        public DuplicateUserCommand(HomeViewModel hwvm)
        {
            this.hwvm = hwvm;
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return this.hwvm.CanDuplicateUser;
        }

        public void Execute(object parameter)
        {
            this.hwvm.DuplicateCurrentUser();
        }
    }
}
