﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class DeleteListCommand : ICommand
    {

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        private HomeViewModel hwvm;

        public DeleteListCommand(HomeViewModel hwvm)
        {
            this.hwvm = hwvm;
        }


        public bool CanExecute(object parameter)
        {
            return this.hwvm.CanDeleteList;
        }

        public void Execute(object parameter)
        {
            this.hwvm.DeleteCurentList();
        }
    }
}
