﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class AddUserCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private HomeViewModel hwmv;

        public AddUserCommand(HomeViewModel hwmv)
        {
            this.hwmv = hwmv;
        }

        public bool CanExecute(object parameter)
        {
            return hwmv.CanAddUser;
        }

        public void Execute(object parameter)
        {
            hwmv.AddUser();
        }
    }
}
