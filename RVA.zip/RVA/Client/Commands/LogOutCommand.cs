﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    public class LogOutCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;


        public LogOutCommand(HomeViewModel viewModel)
        {
            hwvm = viewModel;
        }


        private HomeViewModel hwvm;
        public bool CanExecute(object parameter)
        {
            return hwvm.CanLogOut;
        }

        public void Execute(object parameter)
        {
            hwvm.LogOut();
        }
    }
}
