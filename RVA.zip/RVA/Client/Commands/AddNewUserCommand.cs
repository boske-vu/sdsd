﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    public class AddNewUserCommand : ICommand
    {


        private AddUserViewModel addDj;


        public AddNewUserCommand(AddUserViewModel addDj)
        {
            this.addDj = addDj;
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return this.addDj.CanAddNewUser;
        }

        public void Execute(object parameter)
        {
            this.addDj.AddNewUser();
        }
    }
}
