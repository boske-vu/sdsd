﻿using Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Client.Commands
{
    class FriendRequestsCommand : ICommand
    {
        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        private HomeViewModel hwvm;

        public FriendRequestsCommand(HomeViewModel hwvm)
        {
            this.hwvm = hwvm;
        }


        public bool CanExecute(object parameter)
        {
            return hwvm.CanShowFriendRequests;
        }

        public void Execute(object parameter)
        {
            hwvm.ShowCurrentFriendRequests();
        }
    }
}

