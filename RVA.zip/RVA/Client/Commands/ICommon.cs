﻿namespace Client.Commands
{
    internal interface ICommon
    {
    }
}