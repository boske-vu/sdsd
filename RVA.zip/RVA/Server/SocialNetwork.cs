﻿using Common;
using Common.Acces;
using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class SocialNetwork : ISocialNetwork
    {
        private static SocialNetwork instance;

        private SocialNetwork() { }
        public static SocialNetwork Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new SocialNetwork();
                }
                return instance;
            }
        }
        private ILogger logger = new Logger();

        public ILogger Logger { get => logger; set => logger = value; }
       
        public bool AddUser(User k)
        {
            using (var baza = new SocialDBContext())
            {
                try
                {
                    Logger.LogServer("\nSuccessfully added user: " + k.Name, DateTime.Now);
                    baza.Users.Add(k);
                    baza.SaveChanges();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }

        public User findUserByUsername(string UserName)
        {
            using (var dbContext = new SocialDBContext())
            {
                return dbContext.Users.FirstOrDefault(m => m.Username == UserName);
            }
        }


        public bool ChangeUser(User kk)
        {
            using (var baza = new SocialDBContext())
            {
                try
                {
                    var oldKO = baza.Users.Find(kk.Username);
                    if (oldKO != null)
                    {
                        baza.Users.Remove(oldKO);
                        baza.SaveChanges();
                        baza.Users.Add(kk);
                        baza.SaveChanges();
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch
                {
                    return false;
                }
            }
        }

      
        public bool DuplicateUser(User u)
        {
            Random rnd = new Random();
            int br = rnd.Next(1, 999);
            int br2 = rnd.Next(1, 999);

            Guid g;
            g = Guid.NewGuid();

            using (var baza = new SocialDBContext())
            {
                try
                {
                    var OldSch = baza.Users.Find(u.Username);
                    if (OldSch != null)
                    {
                        User u1 = new User();
                        u1.Name = OldSch.Name;
                        u1.LastName = OldSch.LastName;
                        u1.Username = g.ToString();
                        u1.Password = "a";
                        
                        baza.Users.Add(u1);
                        baza.SaveChanges(); 
                        Logger.LogServer("\nUser Successfully duplicated" + u.Name, DateTime.Now);
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine("Duplicate User: exc:" + e.Message);
                    return false;
                }
            }
        }
        public BindingList<User> GetAllUsers()
        {
            using (var baza = new SocialDBContext())
            {
                return new BindingList<User>(baza.Users.ToList());
            }
        }

        public BindingList<User> GetAllFriends(string username)
        {
            BindingList<User> ret = new BindingList<User>();
            using (var baza = new SocialDBContext())
            {
                User me = baza.Users.Find(username);

                
                if (me.MyUsers == null)
                    return ret;
                
                string[] friendsUserNames = me.MyUsers.Split('|');
                foreach(string friend in friendsUserNames)
                {
                    User f = baza.Users.Find(friend);
                    if(f != null)
                    {
                        ret.Add(f);
                    }
                }

            }
            return ret;
        }

        public BindingList<User> GetAllRequests(string username)
        {
            BindingList<User> ret = new BindingList<User>();

            using (var baza = new SocialDBContext())
            {
                foreach(User u in baza.Users)
                {
                    string[] friendRequests = u.MyUsers.Split('|');
                    foreach (string request in friendRequests)
                    {
                       if(request == username)
                        {
                            ret.Add(u);
                        }
                    }
                }
            }
            return ret;
        }

        public bool DeleteList(User u)
        {
            using (var baza = new SocialDBContext())
            {
                try
                {
                    var OldSch = baza.Users.Find(u.Username);
                    if (OldSch != null)
                    {
                        baza.Users.Attach(OldSch);
                        baza.Users.Remove(OldSch);
                        baza.SaveChanges();
                        Logger.LogServer("\nSuccesfully deleted user: " + u.Username, DateTime.Now);
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch
                {
                    return false;
                }
            }
        }

        public bool AddTypeF(string type)
        {
            return true;
        }


        public bool AddMyFriend(string my_username, string friend_usernames)
        {
            using (var baza = new SocialDBContext())
            {
                baza.UpdateUsersFriendList(my_username, friend_usernames);
            }
            Logger.LogServer("\nSuccessfully Added friend: " + friend_usernames, DateTime.Now);
            return true;
        }

        public bool AcceptFriend(string my_username, string friend_usernames)
        {
            using (var baza = new SocialDBContext())
            {
                baza.UpdateUsersFriendList(my_username, friend_usernames);
            }
            Logger.LogServer("\nUser" + my_username+ "successfully Accepted friend: " + friend_usernames, DateTime.Now);
            return true;
        }

        public bool AddTypeOfFriend(string my_username, string friend_username, string type)
        {
            using (var baza = new SocialDBContext())
            {
                User me = baza.Users.Find(my_username);
                User friend = baza.Users.Find(friend_username);

                string[] friends = me.MyUsers.Split('|');
                string[] types = me.FriendTypes.Split('|');
                int index = -1;
                for (int i = 0; i < friends.Count(); i++)
                {
                    if (friends[i] == friend_username)
                        index = i;
                }

                if(index != -1)
                {
                    types[index] = type;
                    me.FriendTypes = type;
                        //.ToString();
                    baza.UpdateUser(my_username);
                }

                return true;
            }
        }
    }
}
