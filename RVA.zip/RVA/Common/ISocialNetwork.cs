﻿using Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [ServiceContract]
    public interface ISocialNetwork
    {
        [OperationContract]
        User findUserByUsername(string UserName);

        [OperationContract]
        bool AddUser(User k);

        [OperationContract]
        bool ChangeUser(User kk);

        [OperationContract]
        BindingList<User> GetAllUsers();

        [OperationContract]
        BindingList<User> GetAllFriends(string username);

        [OperationContract]
        bool DeleteList(User u);

        [OperationContract]
        bool AddMyFriend(string myusername, string friend_username);

        [OperationContract]
        BindingList<User> GetAllRequests(string username);

        [OperationContract]
        bool AcceptFriend(string my_username, string friend_usernames);

        [OperationContract]
        bool DuplicateUser(User u);

        [OperationContract]
        bool AddTypeF(string type);

        [OperationContract]
        bool AddTypeOfFriend(string my_username, string friend_username, string type);
    }

}

