﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.Entity.Migrations;

namespace Common.Acces
{
    class Configuration : DbMigrationsConfiguration<SocialDBContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
            ContextKey = "SocialDBContext";
        }
    }
}
