﻿using Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Common.Acces
{
    public class SocialDBContext : DbContext
    {
                
        public SocialDBContext() : base("dbSocialNetwork9")
        {
            if (Users.Find("admin") == null)
            {
                User helperAdmin = new User("admin", "admin");
                
                helperAdmin.Name = "Admin";
                helperAdmin.LastName = "Admin";
                helperAdmin.RoleOfUser = "Admin";
                helperAdmin.MyUsers = "";
                Users.Add(helperAdmin);
            }

            SaveChanges();
        }
        public void RemoveUser(string userName)
        {
            Users.Remove(Users.Find(userName));

            //base.Database.ExecuteSqlCommand("delete from Users where Username = '" + userName + "';");
            SaveChanges();
        }
        public void UpdateUsersFriendList(string my_username, string friend_usernames)
        {
            User newMe = new User();
            User u = Users.Find(my_username);
            newMe.Username = u.Username;
            newMe.Name = u.Name;
            newMe.Password = u.Password;
            newMe.LastName = u.LastName;
            newMe.Role = u.Role;
            newMe.RoleOfUser = u.RoleOfUser;
            newMe.MyUsers = u.MyUsers + "|" + friend_usernames;
            newMe.FriendTypes = u.FriendTypes + "|" + FriendType.FRIEND.ToString();
            Users.Remove(u);
            Users.Add(newMe);
            SaveChanges();
        }
        public void UpdateUser(string username)
        {
            User newMe = new User();
            User u = Users.Find(username);
            newMe.Username = u.Username;
            newMe.Name = u.Name;
            newMe.Password = u.Password;
            newMe.LastName = u.LastName;
            newMe.Role = u.Role;
            newMe.RoleOfUser = u.RoleOfUser;
            newMe.MyUsers = u.MyUsers + "|";
            newMe.FriendTypes = u.FriendTypes;
            Users.Remove(u);
            Users.Add(newMe);
            SaveChanges();
        }
        public void AddUserInSql(User u)
        {
            Users.Add(u);
            //base.Database.ExecuteSqlCommand("insert into Users values(" +
            //                                                             "'" + u.Username + "'," +
            //                                                             "'" + u.Password + "'," +
            //                                                             "'" + u.Role + "'," +
            //                                                             "'" + u.Name + "'," +
            //                                                             "'" + u.LastName + "'," +
            //                                                             "'" + u.RoleOfUser + "');");                                 
            SaveChanges();
        }


        public DbSet<User> Users { get; set; }
    }
}
