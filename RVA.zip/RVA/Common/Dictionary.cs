﻿using Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    class Dictionary
    {
        User u = new User();
        private Dictionary<string, List<User>> dictionaryForLoggedUser;

        public Dictionary()
        {
            dictionaryForLoggedUser = new Dictionary<string, List<User>>();
        }
        public Dictionary<string, List<User>> DictionaryForLoggedUser { get => dictionaryForLoggedUser; set => dictionaryForLoggedUser = value; }
    }
}
