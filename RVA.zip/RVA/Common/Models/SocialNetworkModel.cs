﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Common.Models
{
    [DataContract]
    public class SocialNetworkModel : INotifyPropertyChanged
    {

        private int iDSkole;

        private List<User> listOfUsers;
        private string naziv;

        private string opis;

        private int vrsta;

        public SocialNetworkModel()
        {

        }
        public SocialNetworkModel(string n)
        {
            Naziv = n;
        }
        [DataMember]
        public DateTime LastChange { get; set; }
        [DataMember]
        public string Naziv { get => naziv; set => naziv = value; }
        [DataMember]
        public string Opis { get => opis; set => opis = value; }
        [DataMember]
        public int Vrsta { get => vrsta; set => vrsta = value; }
        [DataMember]

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int IDSkole { get => iDSkole; set => iDSkole = value; }
        [DataMember]
        public List<User> ListOfUsers { get => listOfUsers; set => listOfUsers = value; }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
