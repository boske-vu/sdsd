﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Models
{
    public class UndoRedo
    {
        public User Useri { get; set; }
        public string Operation { get; set; }

        public UndoRedo() { }

        public UndoRedo(User ss, string operation)
        {
            Useri = ss;
            Operation = operation;
        }
    }
}
