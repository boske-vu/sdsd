﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Models
{
    public class UndoRedoDataBase
    {
        public static List<UndoRedo> Undo = new List<UndoRedo>();
        public static List<UndoRedo> Redo = new List<UndoRedo>();
    }
}
