﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Common.Models
{
    public class User : INotifyPropertyChanged
    {
        private string role;
        private string username;
        private string name;
        private string lastname;
        private string password;
        private int id;
        private string myUsers;
        private string my;
        private string friendTypes;

        public User()
        {
            myUsers = "";
            FriendTypes = "";
        }
        public User(string u, string p)
        {
            this.Username = u;
            this.Password = p;
        }

        public User(string u, string p, int id)
        {
            this.Username = u;
            this.Password = p;
            this.Id = id;
        }
        [DataMember]
        public string Password { get => password; set => password = value; }
        [DataMember]

        [Key]
        public string Username { get => username; set => username = value; }
        [DataMember]
        public string Role { get => role; set => role = value; }
        [DataMember]
        public string Name { get => name; set => name = value; }
        [DataMember]
        public string LastName { get => lastname; set => lastname = value; }
        [DataMember]
        public string RoleOfUser { get; set; }

        [DataMember]
        public int Id { get => id; set => id = value; }

        [DataMember]
        public string MyUsers { get => myUsers; set => myUsers = value; }
        [DataMember]
        public string FriendTypes { get => friendTypes; set => friendTypes = value; }

        public event PropertyChangedEventHandler PropertyChanged;
    }

}

